# apt-cf-test

## Java app
1) build project : mvn clean install
2) copy apt file to jar :-> jar uf target/deb-test-1.0-SNAPSHOT.jar apt.yml
3) cf p

## Python App
cd into python folder
cf p
